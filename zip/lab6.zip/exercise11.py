#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  7 23:37:19 2019

@author: manuel
"""

# Exercise 11 
# Given the iris dataset, split the dataset into training and test set; use 90% 
# of data for training and 10% for testing. Implement least squares linear 
# regression, using the pseudo-inverse to find the weights that minimize the 
# linear model, in order to predict the PetalWidth using the PetalLength. In 
# order to assess the performance of the model, compute the root mean square error 
# on the test set. Then create a scatter plot of the data points in the two given 
# dimensions, plotting with different colors the points belonging to the training 
# or the test set. Also, plot the line that you have found by applying linear 
# regression.

import math
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import scipy.linalg as la

def plot_data_with_line(frame1, frame2, col1, col2, q, m):
    """
    Print a 2-d scatter plot of the points in the dataframes using col1 and col2;
    pick the color of the points according to the dataframe.
    """    
    plt.plot(frame1[col1], frame1[col2], 'o', label="train")
    plt.plot(frame2[col1], frame2[col2], 'o', label="test")
        
    lower = min(min(frame1[col1]), min(frame2[col1]))
    upper = max(max(frame1[col1]), max(frame2[col1]))            
    xs = np.linspace(lower, upper, 2)
    ys = q + m*xs
    plt.plot(xs, ys, 'r', linewidth=1)
    
    plt.title(col1+" vs "+ col2)
    plt.legend()
    plt.grid(True)
    plt.show()

# -----------------------------------------------------------------------------
    
# read and define data
frame = pd.read_csv("/yourPathHere/iris.data", names = ["SepalLength","SepalWidth","PetalLength","PetalWidth","Class"])

# split into train and test set
train = frame.sample(frac=0.9, random_state=1)
test = frame.drop(train.index)

# create a numpy array with two columns:
# first column contains constants equal to 1
# second column contains the dimension of data points used for building the model
X = np.column_stack([np.ones(train.shape[0]),train["PetalLength"]])
Y = np.array(train["PetalWidth"])

# to solve the linear system, use scipy or numpy (the solutions obtain the same result)

# scipy solution
a = la.solve(X.T @ X, X.T @ Y)

# numpy solution
a = np.linalg.inv(X.T.dot(X)).dot(X.T).dot(Y)

# make predictions on the test set
predictions = a[0] + a[1]*test["PetalLength"]

# compute RMSE on the predictions
errors = (test["PetalWidth"] - predictions)**2
errors_sum = errors.sum()
rms = math.sqrt(errors_sum/test.shape[0])
print("RMSE = {0:.2f}".format(rms))

# plot data points and linear model
plot_data_with_line(train,test,"PetalLength","PetalWidth", a[0], a[1])