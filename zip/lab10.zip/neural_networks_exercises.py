#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 24 11:40:42 2019

@author: manuel
"""
    
# Exercise 16
# Given two datasets of 2 linearly separable clusters of 2-dimensional data, 
# implement a perceptron to separate the clusters.

import numpy as np
import matplotlib.pyplot as plt

def sigmoid(x):
    return 1.0/(1+ np.exp(-x))

class Perceptron:
    def __init__(self, x, y, rate):
                
        self.input = x              # input features of data        
        self.y = y                  # output labels of data
        self.learning_rate = rate   # learning rate (step size)                        
        
        # initialize output of the perceptron to zero
        self.output = np.zeros(self.y.shape)
                
        # initialize weights of the perceptron to very small values
        tmp_weights = []
        for i in range(self.input.shape[1]) :
            tmp_weights.append(np.random.uniform(0, 0.1, 1))            
        self.weights = np.array(tmp_weights)

    def train(self):
        
        # compute the output of the perceptron with current weights     
        self.output = sigmoid(np.dot(self.input, self.weights))        

        # compute the difference between given labels and current output
        loss_function = self.y - self.output
        weights_correction = self.learning_rate * self.input * loss_function                                    
        
        # update current weights (consider the correction of all points)
        self.weights[0] += np.sum(weights_correction[:,0])
        self.weights[1] += np.sum(weights_correction[:,1])

number_of_points = 20
learning_rate = 0.0005
training_epochs = 15

# -- dataset 1 --

# set random seed for reproducibility
np.random.seed(3)

# generate input features of data
points_x = np.random.uniform(-3, -1, number_of_points)
points_y = np.random.uniform(1, 4, number_of_points)
class1 = np.array(list(zip(points_x, points_y)))
points_x = np.random.uniform(1, 3, number_of_points)
points_y = np.random.uniform(2, 4, number_of_points)
class2 = np.array(list(zip(points_x, points_y)))
X = np.concatenate((class1,class2))
    
# generate class label of data
class1_labels = []
class2_labels = []
for i in range(number_of_points): 
    class1_labels.append(np.zeros(1))
    class2_labels.append(np.ones(1))      
y = np.concatenate((np.array(class1_labels), np.array(class2_labels)))

# initialize the perceptron
p = Perceptron(X, y, learning_rate)

# train the perceptron and plot its training
for i in range(training_epochs):        
    # plot points
    plt.plot(class1.T[0], class1.T[1], 'o')
    plt.plot(class2.T[0], class2.T[1], 'o')    
    # compute slope and plot perceptron line
    m = -p.weights[0,0] / p.weights[1,0]
    x_line = np.arange(-4, 5)
    plt.plot(x_line, m * x_line)
    # general plot options
    plt.xlim(-4,4)
    plt.ylim(-4,6)
    weight1 = "{0:.3f}".format(p.weights[0,0])
    weight2 = "{0:.3f}".format(p.weights[1,0])    
    plt.title("{}: $x_2 = - {}/{} \, x_1$".format(i, weight1, weight2))
    plt.grid()
    plt.show()
    
    # train the perceptron
    p.train()

# -- dataset 2 --

# set random seed for reproducibility
np.random.seed(2)

# generate input features of data   
points_x = np.random.uniform(-1, 1, number_of_points)
points_y = np.random.uniform(-1, 1, number_of_points)
class1 = np.array(list(zip(points_x, points_y)))
points_x = np.random.uniform(1, 3, number_of_points)
points_y = np.random.uniform(2, 4, number_of_points)
class2 = np.array(list(zip(points_x, points_y)))
X = np.concatenate((class1,class2))

# generate class label of data
class1_labels = []
class2_labels = []
for i in range(number_of_points): 
    class1_labels.append(np.zeros(1))
    class2_labels.append(np.ones(1))          
y = np.concatenate((np.array(class1_labels), np.array(class2_labels)))

# initialize the perceptron
p = Perceptron(X, y, learning_rate)
    
# train the perceptron
for i in range(training_epochs):      
    # plot points
    plt.plot(class1.T[0], class1.T[1], 'o')
    plt.plot(class2.T[0], class2.T[1], 'o')    
    # compute slope and plot perceptron line
    m = -p.weights[0,0] / p.weights[1,0]    
    x_line = np.arange(-4, 5)
    plt.plot(x_line, m * x_line)    
    # general plot
    plt.xlim(-4,4)
    plt.ylim(-4,6)
    weight1 = "{0:.3f}".format(p.weights[0,0])
    weight2 = "{0:.3f}".format(p.weights[1,0])    
    plt.title("{}: $x_2 = - {}/{} \, x_1$".format(i, weight1, weight2))
    plt.grid()
    plt.show()
    
    # train the perceptron
    p.train()

# ----------------------------------------

# Exercise 17
# Given two datasets of 2 linearly separable clusters of 2-dimensional data, 
# implement a perceptron with bias unit to separate the clusters.

class Perceptron:
    def __init__(self, x, y, rate):
                
        self.input = x              # input features of data        
        self.y = y                  # output labels of data
        self.learning_rate = rate   # learning rate (step size)                        
        
        # initialize output of the perceptron to zero
        self.output = np.zeros(self.y.shape)
                
        # initialize weights of the perceptron to very small values
        tmp_weights = []
        for i in range(self.input.shape[1]) :
            tmp_weights.append(np.random.uniform(0, 0.1, 1))            
        self.weights = np.array(tmp_weights)
        
        # initialize bias weight
        self.bias_weight = np.random.uniform(0, 0.1, 1)

    def train(self):
        
        # compute the output of the perceptron with current weights
        self.output = sigmoid(np.dot(self.input, self.weights) + self.bias_weight)

        # compute the difference between given labels and current output
        loss_function = self.y - self.output
        weights_correction = self.learning_rate * self.input * loss_function
        
        # the bias unit given in input is usually considered with a value of 1
        bias_correction = self.learning_rate * 1 * loss_function                  
        
        # update current weights (consider the correction of all points)
        self.weights[0] += np.sum(weights_correction[:,0])
        self.weights[1] += np.sum(weights_correction[:,1])
        self.bias_weight += np.sum(bias_correction)

number_of_points = 20
learning_rate = 0.0005
training_epochs = 20

# -- dataset 1 --

# set random seed for reproducibility
np.random.seed(3)

# generate input features of data
points_x = np.random.uniform(-3, -1, number_of_points)
points_y = np.random.uniform(1, 4, number_of_points)
class1 = np.array(list(zip(points_x, points_y)))
points_x = np.random.uniform(1, 3, number_of_points)
points_y = np.random.uniform(2, 4, number_of_points)
class2 = np.array(list(zip(points_x, points_y)))
X = np.concatenate((class1,class2))
    
# generate class label of data
class1_labels = []
class2_labels = []
for i in range(number_of_points): 
    class1_labels.append(np.zeros(1))
    class2_labels.append(np.ones(1))      
y = np.concatenate((np.array(class1_labels), np.array(class2_labels)))

# initialize the perceptron
p = Perceptron(X, y, learning_rate)

# train the perceptron and plot its training
for i in range(training_epochs):        
    # plot points
    plt.plot(class1.T[0], class1.T[1], 'o')
    plt.plot(class2.T[0], class2.T[1], 'o')        
    # compute slope, intercept and plot perceptron line
    m = -p.weights[0,0] / p.weights[1,0]
    q = -p.bias_weight[0] / p.weights[1,0]    
    x_line = np.arange(-4, 5)
    plt.plot(x_line, m * x_line + q)
    # general plot options
    plt.xlim(-4,4)
    plt.ylim(-4,6)
    weight1 = "{0:.3f}".format(p.weights[0,0])
    weight2 = "{0:.3f}".format(p.weights[1,0])   
    weight3 = "{0:.3f}".format(p.bias_weight[0])   
    intercept = "{0:.3f}".format(p.weights[1,0])
    plt.title("{}: $x_2 = - {}/{} \, x_1 - {}/{} \, b$".format(i, weight1, weight2, weight3, weight2))
    plt.grid()
    plt.show()
    
    # train the perceptron
    p.train()

number_of_points = 20
learning_rate = 0.1
training_epochs = 20

# -- dataset 2 --

# set random seed for reproducibility
np.random.seed(2)

# generate input features of data   
points_x = np.random.uniform(-1, 1, number_of_points)
points_y = np.random.uniform(-1, 1, number_of_points)
class1 = np.array(list(zip(points_x, points_y)))
points_x = np.random.uniform(1, 3, number_of_points)
points_y = np.random.uniform(2, 4, number_of_points)
class2 = np.array(list(zip(points_x, points_y)))
X = np.concatenate((class1,class2))

# generate class label of data
class1_labels = []
class2_labels = []
for i in range(number_of_points): 
    class1_labels.append(np.zeros(1))
    class2_labels.append(np.ones(1))          
y = np.concatenate((np.array(class1_labels), np.array(class2_labels)))

# initialize the perceptron
p = Perceptron(X, y, learning_rate)

# train the neural network
for i in range(training_epochs):      
    # plot points
    plt.plot(class1.T[0], class1.T[1], 'o')
    plt.plot(class2.T[0], class2.T[1], 'o')    
    # compute slope, intercept and plot perceptron line
    m = -p.weights[0,0] / p.weights[1,0]
    q = -p.bias_weight[0] / p.weights[1,0]    
    x_line = np.arange(-4, 5)
    plt.plot(x_line, m * x_line + q)
    # general plot options
    plt.xlim(-4,4)
    plt.ylim(-4,6)
    weight1 = "{0:.3f}".format(p.weights[0,0])
    weight2 = "{0:.3f}".format(p.weights[1,0])   
    weight3 = "{0:.3f}".format(p.bias_weight[0])   
    intercept = "{0:.3f}".format(p.weights[1,0])
    plt.title("{}: $x_2 = - {}/{} \, x_1 - {}/{} \, b$".format(i, weight1, weight2, weight3, weight2))
    plt.grid()
    plt.show()
    
    # train the perceptron
    p.train()
    
# ----------------------------------------      
    
# Exercise 18
# Given a dataset of 2 linearly separable clusters of data, use keras to
# implement a perceptron with bias unit to separate the clusters.
# FOR MORE INFORMATION: https://keras.io/
    
# TO USE KERAS: keras and theano packages must be installed using Anaconda, 
#               which also automatically installs their dependencies

from keras.models import Sequential
from keras.layers import Dense
import keras.optimizers as optimizers

number_of_points = 20
learning_rate = 0.2
training_epochs = 60

# set random seed for reproducibility
np.random.seed(1)

# generate input features of data   
points_x = np.random.uniform(-1, 1, number_of_points)
points_y = np.random.uniform(-1, 1, number_of_points)
class1 = np.array(list(zip(points_x, points_y)))
points_x = np.random.uniform(1, 3, number_of_points)
points_y = np.random.uniform(2, 4, number_of_points)
class2 = np.array(list(zip(points_x, points_y)))
X = np.concatenate((class1,class2))

# generate class labels of data
class1_labels = []
class2_labels = []
for i in range(number_of_points): 
    class1_labels.append(np.zeros(1))
    class2_labels.append(np.ones(1))          
y = np.concatenate((np.array(class1_labels), np.array(class2_labels)))

# 1) define a structure for the layers of the neural network 
#    (sequential = stack of layers)
model = Sequential()

# 2) add layers with perceptrons to the neural network
model.add(Dense(1, use_bias=True, activation='sigmoid', input_dim=2))

# 3) configure the neural network
model.compile(optimizer = optimizers.SGD(lr = learning_rate), 
              loss = 'mean_squared_error', 
              metrics = ['accuracy'])

# to get information about the layers of the model
model.summary()

# 4) Train the model, iterating on the data in batches of 20 samples
history = model.fit(X, y, epochs=training_epochs, batch_size=20)

# get the first layer
layer = model.layers[0]

# plot points
plt.plot(class1.T[0], class1.T[1], 'o')
plt.plot(class2.T[0], class2.T[1], 'o')    
# compute slope, intercept and plot perceptron line
m = -layer.get_weights()[0][0][0] / layer.get_weights()[0][1][0]
q = -layer.get_weights()[1][0] / layer.get_weights()[0][1][0]
x_line = np.arange(-4, 5)
plt.plot(x_line, m * x_line + q)
# general plot
plt.xlim(-4,4)
plt.ylim(-4,6)    
plt.grid()
plt.show()

# obtain predictions for training data
model.predict(X)  

# --------------------------------------

# Exercise 19
# Using keras, define a neural network to implement the XOR logical operator.

# define training data
X = np.array([[0,0], [0,1], [1,0], [1,1]])
y = np.array([[0],[1],[1],[0]])

# plot points
for index,value in enumerate(X):
    if y[index] == 0:
        plt.plot(value[0], value[1], 'o', color = "blue")
    else:        
        plt.plot(value[0], value[1], 'o', color = "orange")    
plt.xlim(-0.5, 1.5)
plt.ylim(-0.5, 1.5)
plt.grid()
plt.show()

learning_rate = 0.5
training_epochs = 3000

# set random seed for reproducibility
np.random.seed(2)

# define the neural network (2 layers, first = 2 perceptrons, second = 1 perceptron)
model = Sequential()
model.add(Dense(2, use_bias=True, activation='sigmoid', input_dim=2))
model.add(Dense(1, use_bias=True, activation='sigmoid'))
model.summary()

# prepare and train the neural network
model.compile(optimizer = optimizers.SGD(lr = learning_rate), 
              loss = 'mean_squared_error', 
              metrics = ['accuracy'])
history = model.fit(X, y, epochs=training_epochs, batch_size=4)

# extract first layer
first_layer = model.layers[0]

# plot points
for index,value in enumerate(X):
    if y[index] == 0:
        plt.plot(value[0], value[1], 'o', color = "blue")
    else:        
        plt.plot(value[0], value[1], 'o', color = "orange")        
# compute slopes, intercepts and plot perceptrons lines
x_line = np.arange(-5, 5)
m1 = -first_layer.get_weights()[0][0][0] / first_layer.get_weights()[0][1][0]
q1 = -first_layer.get_weights()[1][0] / first_layer.get_weights()[0][1][0]
plt.plot(x_line, m1 * x_line + q1)
m2 = -first_layer.get_weights()[0][0][1] / first_layer.get_weights()[0][1][1]
q2 = -first_layer.get_weights()[1][1] / first_layer.get_weights()[0][1][1]
plt.plot(x_line, m2 * x_line + q2)
# general plot options
plt.xlim(-0.5, 1.5)
plt.ylim(-0.5, 1.5)
plt.grid()
plt.show()

# --------------------------------------

# Exercise 20
# Given two datasets of 2-dimensional data composed by two horizontally 
# (or vertically) aligned clusters, use keras to define an autoencoder to 
# compress data from 2-dimensions to 1-dimension.

# -- case: horizontally aligned data --

number_of_points = 20
learning_rate = 0.5
training_epochs = 100

# set random seed for reproducibility
np.random.seed(1)

# generate input features of data   
points_x = np.random.uniform(-2, 0, number_of_points)
points_y = np.random.uniform(2, 4, number_of_points)
class1 = np.array(list(zip(points_x, points_y)))
points_x = np.random.uniform(1, 3, number_of_points)
points_y = np.random.uniform(2, 4, number_of_points)
class2 = np.array(list(zip(points_x, points_y)))
X = np.concatenate((class1,class2))

# generate class labels of data
class1_labels = []
class2_labels = []
for i in range(number_of_points): 
    class1_labels.append(np.zeros(1))
    class2_labels.append(np.ones(1))      
y = np.concatenate((np.array(class1_labels), np.array(class2_labels)))

# plot points
plt.plot(class1.T[0], class1.T[1], 'o')
plt.plot(class2.T[0], class2.T[1], 'o')
plt.xlim(-4,4)
plt.ylim(-4,6)    
plt.grid()
plt.show()

# define autoencoder
autoencoder = Sequential()
autoencoder.add(Dense(1, activation='sigmoid', input_dim=2))    # encoding layer
autoencoder.add(Dense(2, activation='sigmoid'))                 # decoding layer
autoencoder.summary()

# prepare and train the autoencoder
autoencoder.compile(optimizer = optimizers.SGD(lr = learning_rate), 
                    loss = 'mean_squared_error')
autoencoder.fit(X, X, epochs = training_epochs, batch_size=5)

# extract the trained encoder from the autoencoder, to check its output
encoder_layer = autoencoder.layers[0]
trained_encoder = Sequential()
trained_encoder.add(encoder_layer)
outcome = trained_encoder.predict(X)

# plot points
plt.plot(class1.T[0], class1.T[1], 'o')
plt.plot(class2.T[0], class2.T[1], 'o')        
plt.plot(outcome.T[0][:20], class1.T[1], 'o')
plt.plot(outcome.T[0][20:], class2.T[1], 'o')
# general plot
plt.xlim(-4,4)
plt.ylim(-4,6)    
plt.grid()
plt.show()

# -- case: vertically aligned data --

# set random seed for reproducibility
np.random.seed(1)

# generate input features of data   
points_x = np.random.uniform(1, 3, number_of_points)
points_y = np.random.uniform(-2, 0, number_of_points)
class1 = np.array(list(zip(points_x, points_y)))
points_x = np.random.uniform(1, 3, number_of_points)
points_y = np.random.uniform(1, 3, number_of_points)
class2 = np.array(list(zip(points_x, points_y)))
X = np.concatenate((class1,class2))

# generate class labels of data
class1_labels = []
class2_labels = []
for i in range(number_of_points): 
    class1_labels.append(np.zeros(1))
    class2_labels.append(np.ones(1))      
y = np.concatenate((np.array(class1_labels), np.array(class2_labels)))

# plot points
plt.plot(class1.T[0], class1.T[1], 'o')
plt.plot(class2.T[0], class2.T[1], 'o')
plt.xlim(-4,4)
plt.ylim(-4,6)    
plt.grid()
plt.show()

# define autoencoder
autoencoder = Sequential()
autoencoder.add(Dense(1, activation='sigmoid', input_dim=2))    # encoding layer
autoencoder.add(Dense(2, activation='sigmoid'))                 # decoding layer
autoencoder.summary()

# prepare and train the autoencoder
autoencoder.compile(optimizer = optimizers.SGD(lr = learning_rate), 
                    loss = 'mean_squared_error')
autoencoder.fit(X, X, epochs = training_epochs, batch_size=5)

# extract the trained encoder from the autoencoder, to check its output
encoder_layer = autoencoder.layers[0]
trained_encoder = Sequential()
trained_encoder.add(encoder_layer)
outcome = trained_encoder.predict(X)

# plot points
plt.plot(class1.T[0], class1.T[1], 'o')
plt.plot(class2.T[0], class2.T[1], 'o')        
plt.plot(class1.T[0], outcome.T[0][:20], 'o')
plt.plot(class2.T[0], outcome.T[0][20:], 'o')
# general plot
plt.xlim(-4,4)
plt.ylim(-4,6)    
plt.grid()
plt.show()

# ------------------------------

# Exercise 21
# Given the MNIST dataset, use keras to build an autoencoder for compressing
# images from 784 dimensions to 32 dimensions.

# based on: https://galaxydatatech.com/2018/10/27/simple-autoencoder-with-keras/

# mnist example on autoencoders using keras

from keras.datasets import mnist

# Load data
(X_train,_), (X_test,_) = mnist.load_data()

#Scaling the data to 0 and 1
X_train=X_train.astype('float32')/float(X_train.max())
X_test=X_test.astype('float32')/float(X_test.max())

# Inspect our data (training = 60K images, testing = 10K images)
# All images have a resolution of 28x28)
print("Training set : ",X_train.shape)
print("Testing set : ",X_test.shape)

# Reshaping our images into matrices (The resolution has changed)
X_train=X_train.reshape((len(X_train),np.prod(X_train.shape[1:])))
X_test=X_test.reshape((len(X_test),np.prod(X_test.shape[1:])))
print("Training set : ",X_train.shape)
print("Testing set : ",X_test.shape)

# Creating an autoencoder model
input_dim = X_train.shape[1]
encoding_dim = 32
epoch = 30

# define and train autoencoder
autoencoder=Sequential()
autoencoder.add(Dense(encoding_dim, input_shape=(input_dim,),activation='relu'))
autoencoder.add(Dense(input_dim,activation='sigmoid'))
autoencoder.compile(optimizer=optimizers.SGD(lr=1), loss='mean_squared_error')
autoencoder.fit(X_train,X_train,epochs=epoch, batch_size=256, shuffle=True, validation_data=(X_test,X_test))

# extract encoder layer from autoencoder (to show encoded representations)
encoder_layer = autoencoder.layers[0]
encoder = Sequential()
encoder.add(encoder_layer)

# Test images and prediction
num_images=10
np.random.seed(42)
random_test_images=np.random.randint(X_test.shape[0], size=num_images)
encoded_img=encoder.predict(X_test)
decoded_img=autoencoder.predict(X_test)

# Display the images
plt.figure(figsize=(18,4))
for i, image_idx in enumerate(random_test_images):
    #plot input image
    ax=plt.subplot(3,num_images,i+1)
    plt.imshow(X_test[image_idx].reshape(28,28))
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
                      
    # plot encoded image
    ax = plt.subplot(3, num_images, num_images + i + 1)
    plt.imshow(encoded_img[image_idx].reshape(8, 4))
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)

    # plot reconstructed image
    ax = plt.subplot(3, num_images, 2*num_images + i + 1)
    plt.imshow(decoded_img[image_idx].reshape(28, 28))
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
                      
plt.show()