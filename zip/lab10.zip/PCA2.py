#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May 12 23:44:31 2019

@author: manuel
"""

# Exercise 15
# Given the 2-dimensional points in "pca_data.csv", apply PCA and project the 
# points in 1 dimension according to the eigenvector with largest eigenvalue. 
# Plot the projected points in 1 dimension (to plot them, set the second 
# dimension equal to 0), project them back to 2 dimensions using the orthogonal
# eigenvectors found the first time through PCA and plot such projected points 
# again.

# Then repeat the same process from the original points, but projecting the 
# points according to the eigenvectors but without changing number of dimensions.
# Plot the projected points, project them back using the same orthogonal 
# eigenvectors and plot the projected points.

# Which differences do you see in the plots?

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# read data
path = "pca_data.csv"
A = pd.read_csv(path)

# standardize data (subtract mean and divide by standard deviation of columns)
M = np.mean(A.T, axis=1)
S = np.std(A.T, axis=1)
N = (A - M)/S

# plot standardized data
plt.plot(N["x"], N["y"],'o')
plt.grid()
plt.show()

# compute covariance matrix of data (must be dXd, where d = original dimension)
V = np.cov(N.T)

# compute eigendecomposition of covariance matrix (must obtain d eigenvectors)
eig_vals, eig_vecs = np.linalg.eig(V)

# sort eigenvalues and eigenvectors according to eigenvalues
idx = np.argsort(eig_vals)[::-1] # find the indexes which sort the array (reverse)
eig_vecs = eig_vecs[:,idx]
eig_vals = eig_vals[idx]

# ---------------------

# extract first eigenvector (transpose because eigenvectors are columns here)
projection_vectors = np.array([eig_vecs.T[0]])

# project data in 1-dimension and plot projection
P = np.dot(N, projection_vectors.T)
P = np.insert(P, 1, np.zeros(P.shape[0]), axis=1)
plt.scatter(P[:,0], P[:,1])
plt.grid()
plt.show()

# extract first two eigenvectors (transpose because eigenvectors are columns here)
projection_vectors = np.array([eig_vecs.T[0], eig_vecs.T[1]])

# project data back to 2 dimensions (wrt eigenvectors) and plot projection
P_back = np.dot(P, projection_vectors)
plt.scatter(P_back[:,0], P_back[:,1])
plt.grid()
plt.show()

# ---------------------

# project original data to 2 dimensions (wrt eigenvectors) and plot projection
P = np.dot(N, projection_vectors.T)
plt.scatter(P[:,0], P[:,1])
plt.grid()
plt.xlim(-4,4)
plt.ylim(-4,4)
plt.show()

# project projected data back to 2 dimensions (wrt eigenvectors) and plot projection
P_back = np.dot(P, projection_vectors)
plt.scatter(P_back[:,0], P_back[:,1])
plt.grid()
plt.show()