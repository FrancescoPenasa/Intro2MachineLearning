#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 23:26:21 2019

@author: manuel
"""

# Exercise 6
# Given the iris dataset CSV file and a new unseen vector representing a flower, 
# define a function that classifies the new flower according to the class of 
# its nearest neighbor.

import pandas as pd
import math
import sys

def euclidean_distance(s1,s2):
    """
    Compute the Euclidean distance between two n-dimensional objects.
    """    
    tmpsum = 0
    
    for index,value in enumerate(s1):
        tmpsum += (s1[index]-s2[index])**2
    
    return math.sqrt(tmpsum)

def find_nn_label(frame,newFlower):
    """
    Find the nearest neighbor(nn) in a dataframe.
    """    
    best_distance = sys.maxsize        
    tmpFlower = pd.Series(newFlower)
    
    # iterate over all rows in the dataframe and find the one with smallest distance
    for flowerIndex in range(frame.shape[0]):
        
        # consider all columns of each data vector, except the label
        flower = frame.iloc[flowerIndex,:-1]
        
        # compute the distance wrt to the unlabeled data vector
        distance = euclidean_distance(flower, tmpFlower)
        
        # check if the nearest neighbor data should be updated
        if(distance < best_distance):
            best_distance = distance            
            nn_class = frame.iloc[flowerIndex,-1]
            
    return nn_class

# read data
path = "yourPathHere/iris.data"
frame = pd.read_csv(path, names = ["SepalLength","SepalWidth","PetalLength","PetalWidth","Class"])

flower = [5.2, 2.3, 3.2, 1.1]
prediction = find_nn_label(frame, flower)
print("The flower represented as", flower, "is classified as",prediction)
