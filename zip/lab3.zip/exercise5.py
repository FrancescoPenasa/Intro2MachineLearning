#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 19 00:24:11 2019

@author: manuel
"""

# EXERCISE:
# Given a 1-dimensional vector v with n rows and a 2-dimensional matrix M with n columns, define functions to:
# - compute the dot product of two vectors
# - compute the product of x and M
# TIP: you can use Python lists

import numpy as np

def dot_product(vec1,vec2):    
    sum = 0            
    for id1,i in enumerate(vec1):
        sum += i * vec2[id1]    
    return sum

def product_vector_matrix(vec,matrix):    
    product = []
    for id,i in enumerate(vec):        
        product.append(dot_product(vec,matrix[id,]))            
    return product    

v = np.array([2,1,3])
M = np.array([[1,2,3],[4,5,6],[7,8,9]])

product_arr = np.array(product_vector_matrix(z,A))

print(product_arr)
